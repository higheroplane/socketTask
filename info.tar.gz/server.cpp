#include "tcpip.h"

#define PORTNUM 15000

int main()
{
    Server GameMaster (PORTNUM);
    GameMaster.start();
    return 0;
}

